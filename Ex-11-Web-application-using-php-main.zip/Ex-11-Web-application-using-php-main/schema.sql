CREATE DATABASE IF NOT EXISTS movie_db;
USE movie_db;

DROP TABLE IF EXISTS bookings;

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    movie VARCHAR(100) NOT NULL,
    showdate DATE NOT NULL,
    tickets INT NOT NULL,
    seat VARCHAR(50) NOT NULL,
    snacks VARCHAR(255) DEFAULT 'None',
    special_request TEXT
);

INSERT INTO bookings (fullname, email, phone, movie, showdate, tickets, seat, snacks, special_request) 
VALUES 
('John Doe', 'john.doe@example.com', '9876543210', 'Avatar: The Way of Water', '2026-04-10', 2, 'A1, A2', 'Popcorn, Soda', 'Extra napkins please'),
('Jane Smith', 'jane.smith@example.com', '9123456789', 'Avengers: Endgame', '2026-04-12', 3, 'B4, B5, B6', 'Nachos', 'Wheelchair accessibility needed');