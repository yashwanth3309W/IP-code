/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class NewServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String fullName = request.getParameter("fullname");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String movie = request.getParameter("movie");
        String showDate = request.getParameter("showdate");
        String ticketsStr = request.getParameter("tickets");
        String seat = request.getParameter("seat");
        String[] snacksArr = request.getParameterValues("snacks");
        String specialRequest = request.getParameter("request");

        String snacks = (snacksArr != null) ? String.join(", ", snacksArr) : "None";
        int tickets = (ticketsStr != null && !ticketsStr.isEmpty()) ? Integer.parseInt(ticketsStr) : 1;

        String jdbcURL = "jdbc:mysql://localhost:3306/movie_db?useSSL=false&serverTimezone=UTC";
        String dbUser = "root";       
        String dbPassword = "test@123";   

        boolean isSaved = false;
        String errorMessage = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
                String sql = "INSERT INTO bookings (fullname, email, phone, movie, showdate, tickets, seat, snacks, special_request) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, fullName);
                    pstmt.setString(2, email);
                    pstmt.setString(3, phone);
                    pstmt.setString(4, movie);
                    pstmt.setString(5, showDate);
                    pstmt.setInt(6, tickets);
                    pstmt.setString(7, seat);
                    pstmt.setString(8, snacks);
                    pstmt.setString(9, specialRequest);

                    int rowsInserted = pstmt.executeUpdate();
                    if (rowsInserted > 0) {
                        isSaved = true;
                    }
                }
            }
        } catch (Exception e) {
            errorMessage = e.getMessage();
            e.printStackTrace();
        }

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Booking Status & History</title>");
            out.println("<style>");
            out.println("table { width: 100%; border-collapse: collapse; margin-top: 20px; font-family: Arial, sans-serif; }");
            out.println("th, td { border: 1px solid #ddd; padding: 10px; text-align: left; font-size: 14px; }");
            out.println("th { background-color: #f4f4f4; }");
            out.println("tr:nth-child(even) { background-color: #f9f9f9; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            
            
            if (isSaved) {
                out.println("<h2 style='color: green;'>Ticket Booked & Saved to Database Successfully!</h2>");
                out.println("<p><b>Full Name:</b> " + fullName + "</p>");
                out.println("<p><b>Movie:</b> " + movie + "</p>");
                out.println("<p><b>Show Date:</b> " + showDate + "</p>");
                out.println("<p><b>Tickets:</b> " + tickets + "</p>");
                out.println("<p><b>Seat:</b> " + seat + "</p>");
                out.println("<p><b>Snacks:</b> " + snacks + "</p>");
            } else {
                out.println("<h2 style='color: red;'>Error! Failed to save ticket to database.</h2>");
                out.println("<p><b>Reason:</b> " + errorMessage + "</p>");
            }
            
            
            out.println("<h3>All Booking Records</h3>");
            out.println("<table>");
            out.println("<tr>");
            out.println("<th>ID</th><th>Full Name</th><th>Email</th><th>Phone</th><th>Movie</th><th>Show Date</th><th>Tickets</th><th>Seat</th><th>Snacks</th><th>Special Request</th>");
            out.println("</tr>");

            try (Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM bookings")) {
                
                while (rs.next()) {
                    out.println("<tr>");
                    out.println("<td>" + rs.getInt("id") + "</td>");
                    out.println("<td>" + rs.getString("fullname") + "</td>");
                    out.println("<td>" + rs.getString("email") + "</td>");
                    out.println("<td>" + rs.getString("phone") + "</td>");
                    out.println("<td>" + rs.getString("movie") + "</td>");
                    out.println("<td>" + rs.getDate("showdate") + "</td>");
                    out.println("<td>" + rs.getInt("tickets") + "</td>");
                    out.println("<td>" + rs.getString("seat") + "</td>");
                    out.println("<td>" + rs.getString("snacks") + "</td>");
                    out.println("<td>" + rs.getString("special_request") + "</td>");
                    out.println("</tr>");
                }
            } catch (SQLException e) {
                out.println("<tr><td colspan='10' style='color: red;'>Error fetching records: " + e.getMessage() + "</td></tr>");
            }

            out.println("</table>");
            out.println("<br><a href='index.html'>Book Another Ticket</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Movie Ticket Database Servlet";
    }// </editor-fold>

}