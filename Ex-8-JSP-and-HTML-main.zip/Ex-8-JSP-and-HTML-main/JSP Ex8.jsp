<%-- 
    Document   : result
    Created on : 3 Sep, 2026
    Author     : 24uad113
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Submitted Details</title>
    </head>
    <body>
        <%
            request.setCharacterEncoding("UTF-8");
            String name = request.getParameter("name");
            String username = request.getParameter("username");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String cardnumber = request.getParameter("cardnumber");
            String password = request.getParameter("password");
        %>
        
        <h2>Submitted Details Successfully</h2>
        <p><strong>Full Name:</strong> <%= name %></p>
        <p><strong>Username:</strong> <%= username %></p>
        <p><strong>Email:</strong> <%= email %></p>
        <p><strong>Phone No.:</strong> <%= phone %></p>
        <p><strong>Card Number:</strong> <%= cardnumber %></p>
        <p><strong>Password:</strong> <%= password %></p>
        <br>
        <a href="index.html">Back to Form</a>
    </body>
</html>