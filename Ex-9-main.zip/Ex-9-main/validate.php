<?php
$errors = array();

// Check if form was submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = $_POST['name'] ?? '';
    $email    = $_POST['email'] ?? '';
    $phone    = $_POST['phone'] ?? '';
    $price    = $_POST['price'] ?? '';
    $quantity = $_POST['quantity'] ?? '';

    // Validation checks
    if (empty($name)) {
        $errors[] = "Name cannot be empty.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }
    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        $errors[] = "Invalid phone number (must be 10 digits).";
    }
    if (!is_numeric($price) || $price < 0) {
        $errors[] = "Invalid price amount.";
    }
    if (!is_numeric($quantity) || $quantity < 1) {
        $errors[] = "Invalid quantity.";
    }

    // Output validation errors or proceed with database operations
    if (count($errors) > 0) {
        echo "<h2>Validation Errors</h2><ul>";
        foreach ($errors as $error) {
            echo "<li>" . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . "</li>";
        }
        echo "</ul>";
        echo '<br><a href="index.html">Go Back</a>';
    } else {
        // Database Connection
        $servername = "localhost";
        $username = "root";       
        $password = "test@123";   
        $dbname = "order_db";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Insert into database securely using prepared statements
        $stmt = $conn->prepare("INSERT INTO orders (name, email, phone, price, quantity) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdi", $name, $email, $phone, $price, $quantity);

        if ($stmt->execute()) {
            echo "<h2>Order Submitted Successfully!</h2>";
        } else {
            echo "<p>Database Error: " . htmlspecialchars($stmt->error, ENT_QUOTES, 'UTF-8') . "</p>";
        }

        $stmt->close();

        // Fetch and display ALL records from the database in a table
        echo "<h2></h2>";
        $result = $conn->query("SELECT * FROM orders");

        if ($result && $result->num_rows > 0) {
            echo "<table border='1' cellpadding='8' cellspacing='0'>";
            echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone Number</th><th>Price</th><th>Quantity</th><th>Date</th></tr>";
            
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['email'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['phone'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['price'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['quantity'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['order_date'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No records found in the database.</p>";
        }

        $conn->close();
    }
}
?>