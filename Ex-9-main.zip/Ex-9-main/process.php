<?php
$servername = "localhost";
$username = "root";       
$password = "test@123";   // <-- Added your password here
$dbname = "order_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO orders (name, email, phone, price, quantity) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdi", $name, $email, $phone, $price, $quantity);

    if ($stmt->execute()) {
        echo "<h3>Order submitted successfully!</h3>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>